 
        <!-- footer-->
        <footer class="content-info" role="contentinfo">
                <div class="container">
                
                 <div class="row">
                <div class="sotto-footer">
               
                     
                <div class="icone-social">
              
                </div>
               
                 <p class="copyright" style="color:#C3C100"><a href="<?php echo base_url();?>terms-conditions">Terms & Conditions </a> | <a href="<?php echo base_url();?>privacypolicy">Privacy Policy </a> | <a href="<?php echo base_url();?>welcome/contact_us">Contact Us</a> - &copy; 2015 mplan.in Matrimonials  </p>
                  
                   
                </div>
                </div>
                 
                <input type="hidden" value="<?php echo base_url();?>" id="url" name="url">
                </div>
        </footer>
        
        <!-- footer end -->
        
        
        <!-- Javascript         -->
        
        <script src="<?php echo base_url();?>js/bootstrap.min.js"></script>
        <script src="<?php echo base_url();?>js/jquery.backstretch.min.js"></script>
        
        
        <!-- Core JavaScript Files -->       
        <script src="<?php echo base_url(); ?>js/jquery.easing.min.js"></script>	
        <script src="<?php echo base_url(); ?>js/jquery.scrollTo.js"></script>
        <script src="<?php echo base_url(); ?>js/wow.min.js"></script>
        <!-- Custom Theme JavaScript -->
       <script src="<?php echo base_url(); ?>js/custom.js"></script>
        <script src="<?php echo base_url();?>js/scripts.js"></script>
    </body>

</html>

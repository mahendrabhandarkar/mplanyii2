<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>100% Free Matrimony | Christian Matrimonial | Muslim Matrimonials | Bharat Matrimony</title>
         <link rel="icon" type="image/png" href="<?php echo base_url();?>img/icon.jpg" >
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        
        <meta name="keywords" content="Free Matrimony, Gujarati Matrimony , shaadi, Hindi Matrimony , Matrimonial, Sites Telugu, Telugu Matrimony, Bride, Oriya Matrimony, Bengali ">
        
	<meta name="description" content="Mplan is complete free matrimonial website.We are using advanced search technology. Create your profile and start searching for prospective brides and grooms today">
	<meta name="author" content="Shiva Manhar">    
        
	<meta name="copyright" content="Copyright � 2015 mplan.in">
	
	<meta name="designer" content="shiva manhar">
	<meta name="robots" content="index, auth/register/">
	<meta name="googlebot" content="index, auth/register/">
	<meta name="Distribution" content="Global">

        <!-- CSS -->
        <link rel='stylesheet' href='http://fonts.googleapis.com/css?family=PT+Sans:400,700'>
        <link rel='stylesheet' href='http://fonts.googleapis.com/css?family=Oleo+Script:400,700'>
        <!--<link rel="stylesheet" href="<?php echo base_url();?>css/bootstrap_customiz.min.css">-->
        <link rel="stylesheet" href="<?php echo base_url();?>css/bootstrap.min.css">
	<link rel="stylesheet" href="<?php echo base_url();?>css/full_page.css">
        
        <link rel="stylesheet" href="<?php echo base_url();?>css/dataurl.css">
        
        <link rel="stylesheet" href="<?php echo base_url();?>css/font-awesome.css">
        <meta name="alexaVerifyID" content="WhBcUlec2wxBZQCImPFKg-Hp4lQ"/>
        <meta name="google-site-verification" content="SSQBLbJNYGybBIe_qhID49_4ri_oKLn3hi9f7gBuTJ4" />
        
	
	
	
	<script src="<?php echo base_url();?>js/jquery-2.1.1.min.js"></script> 
	
        <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
        <!--[if lt IE 9]>
	
        <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
            
        <![endif]-->
        <!-- google analysis traking -->
        <script>
		  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
		  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
		  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
		  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');		
		  ga('create', 'UA-63183737-1', 'auto');
		  ga('send', 'pageview');		
	</script>
    </head>

 

        <!-- footer-->

        <footer class="content-info"  role="contentinfo" style='background-color: #9e1533;margin-top:20px;border-top:2px solid #fe4d01;'>

                <div class="container">               

                 <div class="row">

                         

              

                <div class="sotto-footer">

               

                     

                <div class="icone-social">

              

                </div>

               

                 <p class="copyright" style="color:#C3C100;font-size:16px;"><a href="<?php echo base_url();?>terms-conditions">Terms & Conditions </a> | <a href="<?php echo base_url();?>privacypolicy">Privacy Policy </a> | <a href="<?php echo base_url();?>welcome/contact_us">Contact Us</a> &copy; 2015 mplan.in Matrimonials  </p>

                  

                   

                </div>


                </div>
                 

        </footer>



        <!-- footer end -->

        

        

        <!-- Javascript -->
        <input type="hidden" value="<?php echo base_url();?>" id="url" name="url">
        
	<script src="<?php echo base_url();?>js/address.js"></script>
        <script src="<?php echo base_url();?>js/mplan.js"></script>
        <script src="<?php echo base_url(); ?>js/classie.js"></script>
	<script src="<?php echo base_url(); ?>js/cbpViewModeSwitch.js"></script>
        
        
    </body>

</html>


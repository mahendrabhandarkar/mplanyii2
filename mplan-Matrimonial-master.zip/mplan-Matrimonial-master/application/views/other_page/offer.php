<!-- <img src="<?php //echo base_url();?>images/lowest_price.jpg" class="img-responsive">
-->
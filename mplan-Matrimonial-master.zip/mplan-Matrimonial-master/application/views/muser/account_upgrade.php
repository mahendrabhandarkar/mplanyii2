<div class="container">
    <div class="row">
        <center>
        <img src="<?php echo base_url();?>images/introductory_offer.jpg" class="img-responsive" title="introductory offer" style="width:70%">
        </center>
    </div>
</div>
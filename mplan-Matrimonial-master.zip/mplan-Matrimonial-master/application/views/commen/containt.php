<?php
$this->load->view('commen/header');
$this->load->view($page);
$this->load->view('commen/footer');
?>
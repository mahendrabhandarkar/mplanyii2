<html>
    <head>
        <title> <?php if(isset($title)){echo $title;}?> | Mplan.in | Matrimonial Service</title>
	<meta name="description" content="<?php if(isset($descripation)) {echo $descripation; } ?>">
	<meta name="keywords" content="<?php if(isset($keywords)){echo $keywords;}?>">
        <link rel="icon" type="image/png" href="<?php echo base_url(); ?>img/icon.jpg" >
        <script src="<?php echo base_url();?>js/jquery-2.1.1.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="<?php echo base_url();?>css/ass/bootstrap.min.css">
        <!-- Responsive etatag -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
    </head>
    <body>
        <div class="container">
            <div class="row">
                <br/>
                <h3> <a href="<?php echo base_url();?>"> Mplan.in </a></h3>
            </div>
        </div>
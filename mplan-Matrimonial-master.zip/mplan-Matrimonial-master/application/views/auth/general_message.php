hello

<?php echo $message; ?>
<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| Facebook API
|--------------------------------------------------------------------------
*/
$config['facebook_id'] = '1636120506610021';
$config['facebook_secret'] = '7e0a33b855b6f0653b4ca5779d3b59d2';
$config['redirect'] ='http://mplan.in/';

/*
|--------------------------------------------------------------------------
| Google API
|--------------------------------------------------------------------------
*/
$config['google_id'] = '500113587490-4be83mnbevmtf50cp4ttutpmk0n4fc1g.apps.googleusercontent.com';
$config['google_secret'] = '-ZSEkADfyuc8AgQ1R1gJO8YJ';





/* End of file oauth2.php */
/* Location: ./application/config/oauth2.php */